from .accurate import HighAccuracyTLEPredictor

# Backwards compatibility
TLEPredictor = HighAccuracyTLEPredictor
